create table users(
USERNAME varchar(50) not null,
PASSWORD varchar(20) not null,
Full_Name varchar (20) not null,
SEC_Q varchar (50) not null,
ANSWER varchar(20) not null,
primary key(USERNAME)
);