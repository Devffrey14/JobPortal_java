/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.sql.*;
import javax.swing.JOptionPane;


/**
 *
 * @author Jeff_Rey
 */
public class javaconnect {
    Connection conn;
    public static Connection connect() {
        // Making Database Connection once & using multiple times whenever required.
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/job_portal", "root", "chiron2019");
            return conn;
        } catch (ClassNotFoundException | SQLException ex) {
            Object e = null;
            // Log the exception
            JOptionPane.showMessageDialog(null, e);
        return null;
        }
    }
}

